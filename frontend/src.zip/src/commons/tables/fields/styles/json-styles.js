let tableHeaderColors = {
    background: '#DCDCDC',
    borderColor: '#A9A9A9'
};
let tableBodyColors = {
    borderColor: '#A9A9A9'
}

export {
    tableBodyColors,
    tableHeaderColors
}
