export const HOST = {
  backend_api: "http://localhost:8080",
  backend_api_devices: "http://localhost:8081",
};
