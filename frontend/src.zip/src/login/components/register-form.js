import React from "react";
import validate from "./validators/person-validator";
import Button from "react-bootstrap/Button";
import { Col, Row, FormGroup, Input, Label } from "reactstrap";

class RegisterForm extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      errorStatus: 0,
      error: null,
      formIsValid: false,
      formControls: {
        name: { value: "", placeholder: "What is your name?", valid: false, touched: false, validationRules: { minLength: 3, isRequired: true } },
        email: { value: "", placeholder: "Email", valid: false, touched: false, validationRules: { emailValidator: true } },
        age: { value: "", placeholder: "Age", valid: false, touched: false },
        address: { value: "", placeholder: "Address", valid: false, touched: false },
        role: { value: "", placeholder: "Role", valid: false, touched: false },
        password: { value: "", placeholder: "Password", valid: false, touched: false },
      },
    };

    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  handleChange = (event) => {
    const name = event.target.name;
    const value = event.target.value;
    const updatedControls = this.state.formControls;

    const updatedFormElement = updatedControls[name];
    updatedFormElement.value = value;
    updatedFormElement.touched = true;
    updatedFormElement.valid = validate(value, updatedFormElement.validationRules);
    updatedControls[name] = updatedFormElement;

    let formIsValid = true;
    for (let updatedFormElementName in updatedControls) {
      formIsValid = updatedControls[updatedFormElementName].valid && formIsValid;
    }

    this.setState({ formControls: updatedControls, formIsValid });
  };

  handleSubmit() {
    const person = {
      name: this.state.formControls.name.value,
      email: this.state.formControls.email.value,
      age: this.state.formControls.age.value,
      address: this.state.formControls.address.value,
      role: this.state.formControls.role.value,
      password: this.state.formControls.password.value,
    };

    this.props.onRegister(person);
    // this.props.toggle();
  }

  render() {
    return (
        <div>
          <FormGroup id="name">
            <Label for="nameField">Name:</Label>
            <Input
                name="name"
                id="nameField"
                placeholder={this.state.formControls.name.placeholder}
                onChange={this.handleChange}
                value={this.state.formControls.name.value}
                valid={this.state.formControls.name.valid}
                required
            />
            {this.state.formControls.name.touched && !this.state.formControls.name.valid && (
                <div className="error-message">* Name must have at least 3 characters</div>
            )}
          </FormGroup>

          <FormGroup id="email">
            <Label for="emailField"> Email: </Label>
            <Input
                name="email"
                id="emailField"
                placeholder={this.state.formControls.email.placeholder}
                onChange={this.handleChange}
                defaultValue={this.state.formControls.email.value}
                touched={this.state.formControls.email.touched ? 1 : 0}
                valid={this.state.formControls.email.valid}
                required
            />
            {this.state.formControls.email.touched &&
                !this.state.formControls.email.valid && (
                    <div className={"error-message"}>
                      {" "}
                      * Email must have a valid format
                    </div>
                )}
          </FormGroup>

          <FormGroup id="address">
            <Label for="addressField"> Address: </Label>
            <Input
                name="address"
                id="addressField"
                placeholder={this.state.formControls.address.placeholder}
                onChange={this.handleChange}
                defaultValue={this.state.formControls.address.value}
                touched={this.state.formControls.address.touched ? 1 : 0}
                valid={this.state.formControls.address.valid}
                required
            />
          </FormGroup>

          <FormGroup id="age">
            <Label for="ageField"> Age: </Label>
            <Input
                name="age"
                id="ageField"
                placeholder={this.state.formControls.age.placeholder}
                min={0}
                max={100}
                type="number"
                onChange={this.handleChange}
                defaultValue={this.state.formControls.age.value}
                touched={this.state.formControls.age.touched ? 1 : 0}
                valid={this.state.formControls.age.valid}
                required
            />
          </FormGroup>

          <FormGroup id="role">
            <Label for="roleField"> Role: </Label>
            <Input
                type="select"
                name="role"
                id="roleField"
                value={this.state.formControls.role.value}
                onChange={this.handleChange}
                touched={this.state.formControls.role.touched ? 1 : 0}
                valid={this.state.formControls.role.valid}
                required
            >
              <option value="ADMIN">ADMIN</option>
              <option value="CLIENT">CLIENT</option>
            </Input>
          </FormGroup>
          <FormGroup id="password">
            <Label for="passwordField"> Password: </Label>
            <Input
                name="password"
                id="passwordField"
                type="password"
                placeholder={this.state.formControls.password.placeholder}
                onChange={this.handleChange}
                defaultValue={this.state.formControls.password.value}
                touched={this.state.formControls.password.touched ? 1 : 0}
                valid={this.state.formControls.password.valid}
                required
            />
          </FormGroup>
          <Row>
            <Col sm={{ size: "4", offset: 8 }}>
              <Button type="submit" disabled={!this.state.formIsValid} onClick={this.handleSubmit}>
                Submit
              </Button>
            </Col>
          </Row>
        </div>
    );
  }
}

export default RegisterForm;