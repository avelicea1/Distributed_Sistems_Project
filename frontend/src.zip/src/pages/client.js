import React from "react";
import APIResponseErrorMessage from "../commons/errorhandling/api-response-error-message";
import {
    Card,
    CardHeader,
    Col,
    Row,
} from "reactstrap";

import * as API_DEVICES from "../device/api/device-api";
import DeviceTable from "../device/components/device-table";

const cardStyle = {
    borderRadius: "12px",
    boxShadow: "0 4px 8px rgba(0, 0, 0, 0.1)",
    padding: "20px",
    backgroundColor: "#f9f9f9",
};

const cardHeaderStyle = {
    backgroundColor: "#327802",
    color: "white",
    borderRadius: "12px 12px 0 0",
    padding: "15px",
    fontSize: "1.25rem",
    textAlign: "center",
};

class ClientContainer extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            tableData: [],
            isLoaded: false,
            errorStatus: 0,
            error: null,
        };
    }

    componentDidMount() {
        const personId = localStorage.getItem("id");
        if (personId) {
            this.fetchDevicesForPerson(personId);
        } else {
            this.setState({ errorStatus: 404, error: "No person ID found in local storage." });
        }
    }

    fetchDevicesForPerson(personId) {
        return API_DEVICES.getDevicesForPerson(personId, (result, status, err) => {
            if (result !== null && status === 200) {
                this.setState({
                    tableData: result,
                    isLoaded: true,
                });
            } else {
                this.setState({
                    errorStatus: status,
                    error: err,
                });
            }
        });
    }

    render() {
        return (
            <div className="container mt-4">
                <Card style={cardStyle}>
                    <CardHeader style={cardHeaderStyle}>
                        <strong>Devices for Person</strong>
                    </CardHeader>

                    <Row>
                        <Col sm={{ size: "10", offset: 1 }}>
                            {this.state.isLoaded && (
                                <DeviceTable
                                    key={JSON.stringify(this.state.tableData)}
                                    tableData={this.state.tableData}
                                />
                            )}
                            {this.state.errorStatus > 0 && (
                                <APIResponseErrorMessage
                                    errorStatus={this.state.errorStatus}
                                    error={this.state.error}
                                />
                            )}
                        </Col>
                    </Row>
                </Card>
            </div>
        );
    }
}

export default ClientContainer;
